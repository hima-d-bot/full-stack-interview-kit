import React from 'react';\nexport const App = () => <div>Skeleton</div>;
