export const logic = () => /home/ubuntu/skeleton_temp/apps/web/src/hooks/useTasks.ts;
