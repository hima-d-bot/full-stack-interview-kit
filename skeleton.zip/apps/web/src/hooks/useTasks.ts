export const useTasks = () => ({ tasks: [] });
