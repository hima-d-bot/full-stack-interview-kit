from pydantic import BaseModel\nfrom typing import List, Optional\n\nclass Task(BaseModel):\n    pass
