from fastapi import FastAPI\napp = FastAPI()
