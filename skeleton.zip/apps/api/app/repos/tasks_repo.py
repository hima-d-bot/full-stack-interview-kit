class TasksRepo:\n    def get_all(self):\n        pass
