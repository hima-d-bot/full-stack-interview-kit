from fastapi import APIRouter\nrouter = APIRouter()
