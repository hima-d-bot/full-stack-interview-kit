class StatsService:\n    pass
