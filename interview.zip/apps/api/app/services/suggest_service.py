class SuggestService:\n    pass
