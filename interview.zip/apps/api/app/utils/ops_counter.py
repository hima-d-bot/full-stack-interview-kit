class OpsCounter:\n    pass
